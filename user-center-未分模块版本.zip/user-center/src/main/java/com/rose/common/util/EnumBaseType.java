package com.rose.common.util;

public interface EnumBaseType  {
    Integer getKey();
    String getValue();
}
