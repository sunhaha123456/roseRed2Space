package com.rose.mapper;

import com.rose.data.entity.TbSysUserLog;
import tk.mybatis.mapper.common.Mapper;

public interface TbSysUserLogMapper extends Mapper<TbSysUserLog> {
}